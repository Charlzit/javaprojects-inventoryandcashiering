-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2023 at 03:09 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jirahs_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `ID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `AccountType` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`ID`, `Username`, `Password`, `fname`, `mname`, `lname`, `AccountType`, `Age`, `Address`, `Position`) VALUES
(10, 'z', 'z', 'Christian Mark', 'Descallar', 'Mallo', 'User', 19, 'Biao Escuela Tugbok District Davao City', 'Manager'),
(15, 'a', 'a', 'Admin', 'G.', 'Admin', 'Administrator', 19, 'Isulan', 'Owner');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ID` int(11) NOT NULL,
  `categoryname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ID`, `categoryname`) VALUES
(4, 'Soap'),
(5, 'Liquor'),
(7, 'Cigarettes'),
(8, 'Canned Goods'),
(11, 'Junkfoods'),
(13, 'Coffee'),
(14, 'Colgate'),
(15, 'Noodles'),
(16, 'Conditioner'),
(17, 'Oil'),
(18, 'Sauce'),
(19, 'Condiments'),
(20, 'NO CATEGORY_s'),
(21, 'Sugar'),
(23, 'Milk'),
(25, 'Softdrink'),
(26, 'Shampoo'),
(27, 'Biscuit'),
(28, 'Candy'),
(29, 'Rice'),
(30, 'Facial Care');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `ID` int(20) NOT NULL,
  `ItemName` varchar(50) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Price` float NOT NULL,
  `Available_Stocks` int(11) NOT NULL,
  `RetailPrice` decimal(10,2) NOT NULL,
  `profits` decimal(10,2) NOT NULL,
  `damage` int(50) NOT NULL,
  `barcode` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`ID`, `ItemName`, `Description`, `Category`, `Price`, `Available_Stocks`, `RetailPrice`, `profits`, `damage`, `barcode`) VALUES
(999, 'Red Horse', 'Extra Strong Beer', 'Liquor', 90.45, 0, '95.00', '4.55', 70, 1),
(1000, 'Tanduay Regular', 'Junior', 'Canned Goods', 45.5, 120, '50.25', '4.75', 0, 2),
(1002, 'Fruit Soda', 'Lemon', 'Softdrink', 20, 45, '25.00', '5.00', 0, 3),
(1003, 'Quichow', 'Regular', 'Noodles', 12, 97, '14.20', '2.20', 3, 4),
(1004, 'CreamSilk', 'Stunning Shine', 'Shampoo', 3.5, 87, '8.00', '4.50', 5, 5),
(1005, 'Kopiko Brown', 'Twin', 'Coffee', 9.7, 492, '11.35', '1.65', 0, 6),
(1006, 'Palm Oil 1/4', 'Coconut', 'Oil', 15, 132, '18.26', '3.26', 0, 7),
(1007, 'Bioderm Freshen', '60g', 'Soap', 14.5, 222, '15.25', '0.75', 0, 8),
(1008, 'Surf Sun Fresh', '390g', 'Soap', 23.75, 394, '25.00', '1.25', 99, 9),
(1009, 'Wings Solve', 'Powder Floral Fresh 70g', 'Soap', 4.95, 509, '6.00', '1.05', 12, 10),
(1010, 'Silver Swan 350ml', 'Soy Sauce 350ml', 'Sauce', 18.65, 150, '20.00', '1.35', 0, 11),
(1011, 'Presco Sardines', 'Green 155g', 'Canned Goods', 10.6, 595, '12.50', '1.90', 0, 12),
(1012, 'Silver Swan 200ml', 'Soy Sauce 200ml', 'Sauce', 8.6, 713, '10.00', '1.40', 0, 13),
(1013, 'Maggi Magic Sarap', '8g', 'Condiments', 3.1, 610, '5.00', '1.90', 0, 14),
(1014, 'Ajinimoto', '12g Blue', 'Condiments', 3, 30, '5.00', '2.00', 500, 15),
(1015, 'Tanduay Dark', '375ml SR', 'Liquor', 45.25, 613, '50.70', '5.45', 0, 16),
(1016, 'Chopsoy Cane', 'Vinegar 375ml', 'Condiments', 9.95, 657, '11.00', '1.05', 0, 17),
(1017, 'Happy Peanuts', '20s 1Bag', 'Junkfoods', 18, 585, '19.00', '1.00', 0, 18),
(1018, 'Salt 1/4kl', '1/4 kl', 'NO CATEGORY_s', 2, 400, '3.00', '1.00', 0, 19),
(1019, 'Salt 1kl', '1kl', 'NO CATEGORY_s', 7, 414, '8.50', '1.50', 0, 20),
(1020, 'Kinugay Muscuvado', '1/4 kl', 'Sugar', 15, 639, '18.00', '3.00', 0, 21),
(1021, 'Safeguard', 'Big', 'Soap', 20.75, 147, '21.00', '0.25', 0, 22),
(1022, 'Palmolive', 'Pink Alovera Soap', 'Shampoo', 14.25, 86, '16.25', '2.00', 0, 23),
(1024, 'Argentina', 'Bigs', 'Biscuit', 19, 100, '25.00', '6.00', 0, 0),
(1025, 'Ligo Sardines', 'Red', 'Canned Goods', 15, 93, '19.00', '4.00', 92, 0),
(1026, 'Bear Brand 120 g', 'Choco na Gatas', 'Milk', 15.5, 216, '19.50', '4.00', 0, 0),
(1027, 'Fita', 'Fita Cracker Jack and Jills', 'Biscuit', 4.5, 24, '7.50', '3.00', 0, 0),
(1028, 'Rebisco', 'Crackerss', 'Biscuit', 4, 48, '7.00', '3.00', 1, 0),
(1030, 'KrimStix', 'Choco', 'Candy', 20, 459, '24.00', '4.00', 0, 0),
(1031, 'Mentos', 'Cool', 'Candy', 15, 58, '20.00', '5.00', 60, 0),
(1033, '7 tonner', 'Rice', 'Rice', 2000, 87, '2300.00', '300.00', 0, 0),
(1034, 'Kojic', 'good for skin', 'Facial Care', 30, 38, '35.00', '5.00', 0, 1034);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `ID` int(11) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Action` varchar(100) NOT NULL,
  `AccountType` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`ID`, `Date`, `Action`, `AccountType`, `Username`) VALUES
(509, '2023-04-07 02:41 PM', ' Logged in ', 'Guest', 'Christian Mark Mallo'),
(510, '2023-04-07 02:41 PM', ' Logged Out ', 'Guest', 'Christian Mark Mallo'),
(511, '2023-04-07 02:41 PM', ' Logged in ', 'Administrator', 'Mario Marapao'),
(512, '2023-04-07 02:47 PM', ' Logged Out ', 'Administrator', 'Mario Marapao'),
(513, '2023-04-07 03:42 PM', ' Logged in ', 'Guest', 'Christian Mark Mallo'),
(514, '2023-04-07 03:43 PM', ' Logged Out ', 'Guest', 'Christian Mark Mallo'),
(515, '2023-04-07 03:43 PM', ' Logged in ', 'Administrator', 'Mario Marapao'),
(516, '2023-04-07 03:44 PM', ' Logged Out ', 'Administrator', 'Mario Marapao'),
(517, '2023-04-07 03:44 PM', ' Logged in ', 'Administrator', 'Mario Marapao'),
(518, '2023-04-07 03:44 PM', ' Logged Out ', 'Administrator', 'Mario Marapao'),
(519, '2023-04-07 06:22 PM', ' Logged in ', 'Guest', 'Christian Mark Mallo'),
(520, '2023-04-07 06:32 PM', ' Logged Out ', 'Guest', 'Christian Mark Mallo'),
(521, '2023-04-07 07:10 PM', ' Logged in ', 'Guest', 'Christian Mark Mallo'),
(522, '2023-04-07 07:12 PM', ' Logged Out ', 'Guest', 'Christian Mark Mallo'),
(523, '2023-04-07 07:12 PM', ' Logged in ', 'Administrator', 'Mario Marapao'),
(524, '2023-04-07 07:16 PM', ' Logged Out ', 'Administrator', 'Mario Marapao'),
(525, '2023-04-07 07:16 PM', ' Logged in ', 'Administrator', 'Admin Admin'),
(526, '2023-04-07 07:19 PM', ' Logged Out ', 'Administrator', 'Admin Admin'),
(527, '2023-04-07 07:19 PM', ' Logged in ', 'Guest', 'Christian Mark Mallo'),
(528, '2023-04-07 07:19 PM', ' Logged Out ', 'Guest', 'Christian Mark Mallo'),
(529, '2023-04-07 07:19 PM', ' Logged in ', 'Administrator', 'Admin Admin'),
(530, '2023-04-07 07:20 PM', ' Logged Out ', 'Administrator', 'Admin Admin'),
(531, '2023-04-07 07:20 PM', ' Logged in ', 'Guest', 'Christian Mark Mallo'),
(532, '2023-04-07 07:21 PM', ' Logged Out ', 'Guest', 'Christian Mark Mallo'),
(533, '2023-04-07 07:21 PM', ' Logged in ', 'Administrator', 'Admin Admin'),
(534, '2023-04-07 07:21 PM', ' Logged Out ', 'Administrator', 'Admin Admin');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `TransactionNo` int(20) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `ItemCode` int(20) NOT NULL,
  `ItemName` varchar(100) NOT NULL,
  `Quantity` int(100) NOT NULL,
  `Price` int(11) NOT NULL,
  `Total` decimal(10,2) NOT NULL,
  `Profit` decimal(10,2) NOT NULL,
  `Month` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`TransactionNo`, `Date`, `ItemCode`, `ItemName`, `Quantity`, `Price`, `Total`, `Profit`, `Month`) VALUES
(1483, '2023-04-07 07:11 PM', 16, 'Tanduay Dark', 2, 51, '101.40', '10.90', 7),
(1484, '2023-04-07 07:11 PM', 17, 'Chopsoy Cane', 3, 11, '33.00', '3.15', 7),
(1485, '2023-04-07 07:20 PM', 1034, 'Kojic', 2, 35, '70.00', '10.00', 7),
(1486, '2023-04-07 07:20 PM', 16, 'Tanduay Dark', 20, 51, '1014.00', '109.00', 7);

-- --------------------------------------------------------

--
-- Table structure for table `stockout`
--

CREATE TABLE `stockout` (
  `ItemCode` int(200) NOT NULL,
  `ItenName` varchar(200) NOT NULL,
  `Stockout` int(200) NOT NULL,
  `Date` varchar(200) NOT NULL,
  `Name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `stockout`
--

INSERT INTO `stockout` (`ItemCode`, `ItenName`, `Stockout`, `Date`, `Name`) VALUES
(1033, '7 tonner', 1, '2019-29-01 02:29 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 3, '2019-29-01 02:56 PM', 'Christian Mark Mallo'),
(1033, '7 tonner', 2, '2019-29-01 02:56 PM', 'Christian Mark Mallo'),
(1033, '7 tonner', 2, '2019-29-01 02:57 PM', 'Christian Mark Mallo'),
(1023, 'Silka', 3, '2019-29-01 04:06 PM', 'Christian Mark Mallo'),
(1007, 'Bioderm Freshen', 2, '2019-29-01 04:06 PM', 'Christian Mark Mallo'),
(1021, 'Safeguard', 3, '2019-29-01 04:06 PM', 'Christian Mark Mallo'),
(1030, 'KrimStix', 2, '2019-29-01 04:09 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 2, '2019-29-01 04:09 PM', 'Christian Mark Mallo'),
(1008, 'Surf Sun Fresh', 3, '2019-29-01 04:28 PM', 'Christian Mark Mallo'),
(1015, 'Tanduay Dark', 3, '2019-29-01 04:28 PM', 'Christian Mark Mallo'),
(1000, 'Tanduay Regular', 2, '2019-29-01 04:28 PM', 'Christian Mark Mallo'),
(1009, 'Wings Solve', 7, '2019-29-01 04:32 PM', 'Christian Mark Mallo'),
(1012, 'Silver Swan 200ml', 7, '2019-29-01 04:32 PM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 3, '2019-29-01 04:32 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 3, '2019-29-01 04:33 PM', 'Christian Mark Mallo'),
(1018, 'Salt 1/4kl', 42, '2019-29-01 04:42 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 3, '2019-29-01 04:42 PM', 'Christian Mark Mallo'),
(1028, 'Rebisco', 3, '2019-29-01 04:43 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 3, '2019-29-01 04:43 PM', 'Christian Mark Mallo'),
(1028, 'Rebisco', 3, '2019-29-01 04:43 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 2, '2019-29-01 04:43 PM', 'Christian Mark Mallo'),
(1033, '7 tonner', 1, '2019-29-01 04:46 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 7, '2019-29-01 04:46 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 1, '2019-29-01 05:02 PM', 'Christian Mark Mallo'),
(1002, 'Fruit Soda', 2, '2019-29-01 05:02 PM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 3, '2019-29-01 05:02 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 1, '2019-29-01 05:06 PM', 'Christian Mark Mallo'),
(1002, 'Fruit Soda', 2, '2019-29-01 05:06 PM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 3, '2019-29-01 05:06 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 2, '2019-29-01 05:08 PM', 'Christian Mark Mallo'),
(1019, 'Salt 1kl', 2, '2019-29-01 05:08 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 2, '2019-30-01 11:24 AM', 'Christian Mark Mallo'),
(1013, 'Maggi Magic Sarap', 3, '2019-30-01 11:24 AM', 'Christian Mark Mallo'),
(1003, 'Quichow', 4, '2019-30-01 11:24 AM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 4, '2019-30-01 11:29 AM', 'Christian Mark Mallo'),
(1013, 'Maggi Magic Sarap', 3, '2019-30-01 11:29 AM', 'Christian Mark Mallo'),
(1020, 'Kinugay Muscuvado', 2, '2019-30-01 11:29 AM', 'Christian Mark Mallo'),
(1031, 'Mentos', 1, '2019-30-01 11:29 AM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 5, '2019-30-01 11:53 AM', 'Christian Mark Mallo'),
(1013, 'Maggi Magic Sarap', 4, '2019-30-01 11:53 AM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 1, '2019-30-01 11:53 AM', 'Christian Mark Mallo'),
(1028, 'Rebisco', 3, '2019-30-01 11:53 AM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 3, '2019-30-01 11:55 AM', 'Christian Mark Mallo'),
(1013, 'Maggi Magic Sarap', 2, '2019-30-01 11:55 AM', 'Christian Mark Mallo'),
(999, 'Red Horse', 1, '2019-30-01 11:55 AM', 'Christian Mark Mallo'),
(1009, 'Wings Solve', 5, '2019-30-01 11:58 AM', 'Christian Mark Mallo'),
(1023, 'Silka', 4, '2019-30-01 11:58 AM', 'Christian Mark Mallo'),
(1012, 'Silver Swan 200ml', 3, '2019-30-01 11:58 AM', 'Christian Mark Mallo'),
(1020, 'Kinugay Muscuvado', 2, '2019-30-01 11:58 AM', 'Christian Mark Mallo'),
(1030, 'KrimStix', 1, '2019-30-01 11:58 AM', 'Christian Mark Mallo'),
(999, 'Red Horse', 4, '2019-30-01 05:09 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 2, '2019-30-01 05:09 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 2, '2019-30-01 05:20 PM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 2, '2019-30-01 05:20 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 3, '2019-30-01 05:20 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 2, '2019-30-01 05:28 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 3, '2019-30-01 05:28 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 3, '2019-30-01 05:33 PM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 5, '2019-30-01 05:33 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 5, '2019-30-01 05:33 PM', 'Christian Mark Mallo'),
(1028, 'Rebisco', 2, '2019-30-01 05:33 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 1, '2019-30-01 05:34 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 2, '2019-30-01 05:34 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 3, '2019-30-01 05:34 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 4, '2019-30-01 05:34 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 1, '2019-30-01 05:43 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 2, '2019-30-01 05:43 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 3, '2019-30-01 05:43 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 4, '2019-30-01 05:43 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 5, '2019-30-01 05:43 PM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 1, '2019-30-01 05:45 PM', 'Christian Mark Mallo'),
(1015, 'Tanduay Dark', 2, '2019-30-01 05:45 PM', 'Christian Mark Mallo'),
(1000, 'Tanduay Regular', 3, '2019-30-01 05:45 PM', 'Christian Mark Mallo'),
(1022, 'Palmolive', 4, '2019-30-01 05:45 PM', 'Christian Mark Mallo'),
(1020, 'Kinugay Muscuvado', 3, '2019-30-01 05:48 PM', 'Christian Mark Mallo'),
(1011, 'Presco Sardines', 2, '2019-30-01 05:48 PM', 'Christian Mark Mallo'),
(1023, 'Silka', 2, '2019-30-01 05:51 PM', 'Christian Mark Mallo'),
(1023, 'Silka', 1, '2019-30-01 05:51 PM', 'Christian Mark Mallo'),
(1023, 'Silka', 4, '2019-30-01 05:51 PM', 'Christian Mark Mallo'),
(1003, 'Quichow', 3, '2019-02-02 12:52 PM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 2, '2019-02-02 12:52 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 1, '2019-02-02 12:52 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 3, '2019-02-02 12:54 PM', 'Christian Mark Mallo'),
(1030, 'KrimStix', 2, '2019-02-02 12:54 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 3, '2019-02-02 12:59 PM', 'Christian Mark Mallo'),
(1028, 'Rebisco', 2, '2019-02-02 12:59 PM', 'Christian Mark Mallo'),
(1026, 'Bear Brand 120 g', 3, '2019-02-02 12:59 PM', 'Christian Mark Mallo'),
(1005, 'Kopiko Brown', 3, '2019-02-02 12:59 PM', 'Christian Mark Mallo'),
(1020, 'Kinugay Muscuvado', 2, '2019-02-02 01:02 PM', 'Christian Mark Mallo'),
(1012, 'Silver Swan 200ml', 3, '2019-02-02 01:02 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 2, '2019-02-02 01:04 PM', 'Christian Mark Mallo'),
(1026, 'Bear Brand 120 g', 2, '2019-02-02 01:04 PM', 'Christian Mark Mallo'),
(1017, 'Happy Peanuts', 2, '2019-02-02 01:07 PM', 'Christian Mark Mallo'),
(1026, 'Bear Brand 120 g', 2, '2019-02-02 01:07 PM', 'Christian Mark Mallo'),
(1028, 'Rebisco', 2, '2019-02-02 01:10 PM', 'Christian Mark Mallo'),
(1025, 'Ligo Sardines', 2, '2019-02-02 01:10 PM', 'Christian Mark Mallo'),
(1033, '7 tonner', 1, '2019-02-02 01:13 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 2, '2019-02-02 01:13 PM', 'Christian Mark Mallo'),
(1002, 'Fruit Soda', 3, '2019-02-02 01:13 PM', 'Christian Mark Mallo'),
(1030, 'KrimStix', 3, '2019-02-02 01:51 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 2, '2019-02-02 01:51 PM', 'Christian Mark Mallo'),
(1030, 'KrimStix', 2, '2019-02-02 01:53 PM', 'Christian Mark Mallo'),
(1013, 'Maggi Magic Sarap', 4, '2019-02-02 01:53 PM', 'Christian Mark Mallo'),
(1026, 'Bear Brand 120 g', 2, '2019-02-02 01:54 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 2, '2019-02-02 01:54 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 2, '2019-02-02 01:59 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 3, '2019-02-02 01:59 PM', 'Christian Mark Mallo'),
(1026, 'Bear Brand 120 g', 2, '2019-02-02 02:02 PM', 'Christian Mark Mallo'),
(1026, 'Bear Brand 120 g', 2, '2019-02-02 02:02 PM', 'Christian Mark Mallo'),
(1002, 'Fruit Soda', 3, '2019-02-02 02:04 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 2, '2019-02-02 02:04 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 1, '2019-02-02 02:04 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 2, '2019-02-02 02:06 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 3, '2019-02-02 02:06 PM', 'Christian Mark Mallo'),
(1030, 'KrimStix', 2, '2019-02-02 02:11 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 2, '2019-02-02 02:11 PM', 'Christian Mark Mallo'),
(1030, 'KrimStix', 20, '2019-02-02 02:13 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 10, '2019-02-02 02:13 PM', 'Christian Mark Mallo'),
(1030, 'KrimStix', 2, '2019-02-02 02:16 PM', 'Christian Mark Mallo'),
(1033, '7 tonner', 1, '2019-02-02 02:16 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 3, '2019-02-02 02:19 PM', 'Christian Mark Mallo'),
(1027, 'Fita', 4, '2019-02-02 02:19 PM', 'Christian Mark Mallo'),
(1031, 'Mentos', 2, '2019-02-02 02:19 PM', 'Christian Mark Mallo'),
(1014, 'Ajinimoto', 7, '2019-06-02 08:37 PM', 'Christian Mark Mallo'),
(1013, 'Maggi Magic Sarap', 2, '2019-06-02 08:37 PM', 'Christian Mark Mallo'),
(1033, '7 tonner', 1, '2019-11-02 11:28 AM', 'Christian Mark Mallo'),
(16, 'Tanduay Dark', 2, '2023-04-07 07:12 PM', 'Christian Mark Mallo'),
(17, 'Chopsoy Cane', 3, '2023-04-07 07:12 PM', 'Christian Mark Mallo'),
(1034, 'Kojic', 2, '2023-04-07 07:21 PM', 'Christian Mark Mallo'),
(16, 'Tanduay Dark', 20, '2023-04-07 07:21 PM', 'Christian Mark Mallo');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `Item Code` int(100) NOT NULL,
  `Item Name` varchar(100) NOT NULL,
  `Stock In` int(100) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`Item Code`, `Item Name`, `Stock In`, `Date`, `Name`) VALUES
(1027, 'Fita', 100, '2019-28-01 10:59 AM', 'Mario Marapao'),
(1028, 'Rebisco', 100, '2019-28-01 11:00 AM', 'Mario Marapao'),
(1031, 'Mentos', 50, '2019-28-01 11:04 AM', 'Mario Marapao'),
(1033, '7 tonner', 100, '2019-28-01 11:14 AM', 'Mario Marapao'),
(1033, '7 tonner', 2, '2019-29-01 01:47 PM', 'Mario Marapao'),
(1002, 'Fruit Soda', 3, '2019-29-01 02:25 PM', 'Christian Mark Mallo'),
(999, 'Red Horse', 4, '2019-29-01 02:25 PM', 'Christian Mark Mallo'),
(1010, 'Silver Swan 350ml', 5, '2019-30-01 11:25 AM', 'Mario Marapao'),
(1014, 'Ajinimoto', 3, '2019-30-01 11:25 AM', 'Mario Marapao'),
(1003, 'Quichow', 8, '2019-02-02 12:51 PM', 'Mario Marapao'),
(1013, 'Maggi Magic Sarap', 5, '2019-11-02 11:17 AM', 'Mario Marapao'),
(1034, 'Kojic', 40, '2023-04-07 07:20 PM', 'Admin Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`TransactionNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1035;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=535;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `TransactionNo` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1487;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
